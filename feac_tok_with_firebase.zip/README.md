# feac-tok (Flutter) - Full scaffold

This repository is a sizeable scaffold for a TikTok-like app called **feac-tok** with:
- Blue theme, white background.
- Email/password authentication (Firebase Auth) scaffold.
- Video feed stored in Firestore (documents with video URL, thumbnail, title, author).
- Video playback (video_player + chewie).
- Download videos to device storage using Dio and permission_handler.
- Likes and comments stored in Firestore.
- Share, cached thumbnails, local notifications placeholders.
- Ready for Android and Windows (desktop) builds.

IMPORTANT:
- You MUST add Firebase configuration files:
  - Android: `android/app/google-services.json`
  - iOS: `ios/Runner/GoogleService-Info.plist`
  - Windows: follow FlutterFire docs for desktop (or use web fallback).
- Initialize Firebase in `main.dart` (already scaffolded); follow FlutterFire CLI to configure.

I cannot produce signed APKs or Windows installers here. This project is ready to build locally or via CI once you add your Firebase configs.

To run:
1. Install Flutter SDK: https://flutter.dev
2. Add Firebase config files and enable Auth, Firestore, Storage.
3. From project root:
   ```
   flutter pub get
   flutter run
   ```
4. To build release APK:
   ```
   flutter build apk --release
   ```

If you want, I can:
- Populate Firestore with sample video entries (give me a list of URLs).
- Help configure CI (GitHub Actions) to build APKs automatically.
- Provide step-by-step Firebase setup instructions.
