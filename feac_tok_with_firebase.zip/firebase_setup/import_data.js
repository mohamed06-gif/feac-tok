/*
Usage:
  1. Place your service account JSON key in this folder (e.g. serviceAccountKey.json)
  2. Run: node import_data.js ./serviceAccountKey.json your-project-id
This will import sample documents into the 'videos' collection.
*/
const admin = require('firebase-admin');
const fs = require('fs');
if (process.argv.length < 4) {
  console.error('Usage: node import_data.js <serviceAccountKey.json> <projectId>');
  process.exit(1);
}
const keyPath = process.argv[2];
const projectId = process.argv[3];
const serviceAccount = require(keyPath);

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  projectId: projectId
});

const db = admin.firestore();

async function importVideos() {
  const data = JSON.parse(fs.readFileSync('sample_data_videos.json', 'utf8'));
  for (let i = 0; i < data.length; i++) {
    const doc = data[i];
    // convert createdAt placeholder
    if (doc.createdAt && doc.createdAt._seconds) {
      doc.createdAt = new admin.firestore.Timestamp(doc.createdAt._seconds, doc.createdAt._nanoseconds || 0);
    } else {
      doc.createdAt = admin.firestore.FieldValue.serverTimestamp();
    }
    const res = await db.collection('videos').add(doc);
    console.log('Added:', res.id);
  }
  console.log('Import finished.');
  process.exit(0);
}

importVideos().catch(err => { console.error(err); process.exit(1); });
