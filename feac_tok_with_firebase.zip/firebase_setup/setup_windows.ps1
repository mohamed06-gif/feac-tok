\
# PowerShell helper for Firebase setup (Windows)
# Run this in the `firebase_setup` folder after placing serviceAccountKey.json inside it.
# Requires: Node.js and Firebase CLI (npm i -g firebase-tools)
Write-Host "1) Login to Firebase CLI"
firebase login

Write-Host "2) Create or select a Firebase project (follow interactive prompts)"
firebase projects:create feac-tok-$(Get-Random -Minimum 1000 -Maximum 9999)

Write-Host "3) Enable Firestore and Storage in the Firebase Console (open browser)"
Start-Process "https://console.firebase.google.com/project"

Write-Host "4) Import sample data (requires serviceAccountKey.json and your project id)"
Write-Host "Usage: node import_data.js ./serviceAccountKey.json your-project-id"

Write-Host "After import, run in the Flutter project root:"
Write-Host "  flutterfire configure"
Write-Host "  flutter pub get"
Write-Host "  flutter run -d windows"
