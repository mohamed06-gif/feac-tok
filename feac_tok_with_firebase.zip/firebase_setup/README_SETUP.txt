Firebase setup helper for feac-tok
---------------------------------

Hello — I prepared helper scripts and sample data to make connecting the app to Firebase easier for you (drwr0600016@gmail.com).

What I included:
1. sample_data/videos.json  -> sample Firestore documents for 'videos' collection
2. import_data.js           -> Node.js script using Firebase Admin SDK to import sample data
3. firebase.rules           -> example Firestore security rules (starter)
4. firebase.json            -> example Firebase CLI config for hosting/firestore (optional)
5. setup_windows.ps1        -> PowerShell step-by-step commands to create a Firebase project, enable services, and run the importer (you will run these locally)
6. setup_unix.sh            -> Similar commands for macOS/Linux
7. README_SETUP.txt         -> Detailed step-by-step instructions (below)

Important limitations:
- I cannot create the Firebase project or upload data to your console without your account access. You must run the provided scripts locally on your machine where you are signed into your Google account.
- The Node importer requires a Firebase service account key (instructions included in README_SETUP.txt).
- After you run the steps, the Flutter project (in the parent folder) will be ready to run: `flutter pub get` then `flutter run -d windows`

README summary (full details in README_SETUP.txt):
1. Install Node.js and Firebase CLI: `npm install -g firebase-tools`
2. Login: `firebase login` (use your Google account: drwr0600016@gmail.com)
3. Create a Firebase project or use an existing one.
4. Enable Firestore and Storage in the Firebase console.
5. Generate a service account key (for server admin import): Go to Console > Project Settings > Service accounts > Generate new private key. Save as `serviceAccountKey.json` in `firebase_setup/`.
6. Run `node import_data.js ./serviceAccountKey.json your-project-id` to import sample videos into `videos` collection.
7. Run `flutterfire configure` in the Flutter project folder to generate `lib/firebase_options.dart` (requires FlutterFire CLI).
8. Add `google-services.json` to `android/app/` if you plan to build Android.

If you want, I can guide you step-by-step while you run these commands and verify the result.

