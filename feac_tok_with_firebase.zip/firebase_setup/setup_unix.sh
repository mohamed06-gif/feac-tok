#!/bin/bash
# Unix helper for Firebase setup
echo "1) Login to Firebase CLI"
firebase login

echo "2) Create a Firebase project (or use existing)"
echo "Run: firebase projects:create <project-id>"

echo "3) Enable Firestore & Storage in the Firebase Console"
echo "Open: https://console.firebase.google.com/"
sleep 2

echo "4) Import sample data (requires serviceAccountKey.json and your project id)"
echo "Usage: node import_data.js ./serviceAccountKey.json your-project-id"

echo "After import, run in the Flutter project root:"
echo "  flutterfire configure"
echo "  flutter pub get"
echo "  flutter run -d windows"
