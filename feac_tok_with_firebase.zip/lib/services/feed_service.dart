import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/video_item.dart';

class FeedService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  Stream<List<VideoItem>> feedStream() {
    return _db.collection('videos').orderBy('createdAt', descending: true).snapshots().map((snap) {
      return snap.docs.map((d) => VideoItem.fromMap(d.id, d.data() as Map<String, dynamic>)).toList();
    });
  }
}
