class VideoItem {
  final String id;
  final String url;
  final String thumbnail;
  final String title;
  final String author;
  final int likes;
  final int comments;

  VideoItem({
    required this.id,
    required this.url,
    required this.thumbnail,
    required this.title,
    required this.author,
    required this.likes,
    required this.comments,
  });

  factory VideoItem.fromMap(String id, Map<String, dynamic> m) {
    return VideoItem(
      id: id,
      url: m['url'] ?? '',
      thumbnail: m['thumbnail'] ?? '',
      title: m['title'] ?? '',
      author: m['author'] ?? '',
      likes: m['likes'] ?? 0,
      comments: m['comments'] ?? 0,
    );
  }
}
