class Comment {
  final String id;
  final String userId;
  final String text;
  final DateTime createdAt;

  Comment({required this.id, required this.userId, required this.text, required this.createdAt});

  factory Comment.fromMap(String id, Map<String, dynamic> m) {
    return Comment(
      id: id,
      userId: m['userId'] ?? '',
      text: m['text'] ?? '',
      createdAt: (m['createdAt'] as DateTime?) ?? DateTime.now(),
    );
  }
}
