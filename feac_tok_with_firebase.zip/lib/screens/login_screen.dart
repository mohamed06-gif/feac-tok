import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/auth_service.dart';

class LoginScreen extends StatefulWidget {
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _email = TextEditingController();
  final _pass = TextEditingController();
  bool _loading = false;
  String? _error;

  @override
  Widget build(BuildContext context) {
    final auth = Provider.of<AuthService>(context);
    return Scaffold(
      appBar: AppBar(title: Text('feac-tok - تسجيل الدخول')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(controller: _email, decoration: InputDecoration(labelText: 'البريد الإلكتروني')),
            TextField(controller: _pass, decoration: InputDecoration(labelText: 'كلمة المرور'), obscureText: true),
            SizedBox(height: 12),
            if (_error != null) Text(_error!, style: TextStyle(color: Colors.red)),
            ElevatedButton(
              onPressed: _loading ? null : () async {
                setState(() { _loading = true; _error = null; });
                final err = await auth.signIn(_email.text.trim(), _pass.text.trim());
                setState(() { _loading = false; });
                if (err != null) setState(() { _error = err; });
              },
              child: _loading ? CircularProgressIndicator(color: Colors.white) : Text('دخول'),
            ),
            TextButton(onPressed: () async {
              // quick sign up flow
              setState(() { _loading = true; _error = null; });
              final err = await auth.signUp(_email.text.trim(), _pass.text.trim());
              setState(() { _loading = false; });
              if (err != null) setState(() { _error = err; });
            }, child: Text('إنشاء حساب جديد')),
          ],
        ),
      ),
    );
  }
}
