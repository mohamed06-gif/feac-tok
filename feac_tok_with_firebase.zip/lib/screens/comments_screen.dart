import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class CommentsScreen extends StatefulWidget {
  final String videoId;
  CommentsScreen({required this.videoId});
  @override
  _CommentsScreenState createState() => _CommentsScreenState();
}

class _CommentsScreenState extends State<CommentsScreen> {
  final _controller = TextEditingController();
  final _db = FirebaseFirestore.instance;

  void _post() {
    final text = _controller.text.trim();
    if (text.isEmpty) return;
    _db.collection('videos').doc(widget.videoId).collection('comments').add({
      'text': text,
      'createdAt': FieldValue.serverTimestamp(),
      'userId': 'anonymous',
    });
    _controller.clear();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('التعليقات')),
      body: Column(
        children: [
          Expanded(child: StreamBuilder<QuerySnapshot>(
            stream: _db.collection('videos').doc(widget.videoId).collection('comments').orderBy('createdAt', descending: true).snapshots(),
            builder: (context, snap) {
              if (!snap.hasData) return Center(child: CircularProgressIndicator());
              final docs = snap.data!.docs;
              return ListView.builder(itemCount: docs.length, itemBuilder: (_, i) {
                final d = docs[i];
                return ListTile(title: Text(d['text'] ?? ''), subtitle: Text(d['userId'] ?? ''));
              });
            },
          )),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(children: [
              Expanded(child: TextField(controller: _controller, decoration: InputDecoration(hintText: 'اكتب تعليق...'))),
              IconButton(icon: Icon(Icons.send), onPressed: _post)
            ]),
          )
        ],
      ),
    );
  }
}
