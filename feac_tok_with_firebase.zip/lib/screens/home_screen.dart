import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:video_player/video_player.dart';
import '../services/feed_service.dart';
import '../models/video_item.dart';
import '../services/storage_service.dart';
import '../services/auth_service.dart';
import 'comments_screen.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final FeedService _feed = FeedService();
  PageController _pageController = PageController();
  int _current = 0;
  Map<int, VideoPlayerController> _controllers = {};

  @override
  void dispose() {
    _controllers.forEach((k, c) => c.dispose());
    _pageController.dispose();
    super.dispose();
  }

  void _initController(int index, String url) {
    if (_controllers.containsKey(index)) return;
    final c = VideoPlayerController.network(url)..initialize().then((_) {
      setState(() {});
      if (index == _current) c.play();
    });
    c.setLooping(true);
    _controllers[index] = c;
  }

  void _pause(int index) {
    final c = _controllers[index];
    if (c != null && c.value.isPlaying) c.pause();
  }

  void _play(int index) {
    final c = _controllers[index];
    if (c != null && !c.value.isPlaying) c.play();
  }

  @override
  Widget build(BuildContext context) {
    final auth = Provider.of<AuthService>(context);
    return Scaffold(
      appBar: AppBar(title: Text('feac-tok')),
      body: StreamBuilder<List<VideoItem>>(
        stream: _feed.feedStream(),
        builder: (context, snap) {
          if (!snap.hasData) return Center(child: CircularProgressIndicator());
          final items = snap.data!;
          return PageView.builder(
            scrollDirection: Axis.vertical,
            itemCount: items.length,
            controller: _pageController,
            onPageChanged: (index) {
              _pause(_current);
              _current = index;
              _initController(index, items[index].url);
              _play(index);
              if (index+1 < items.length) _initController(index+1, items[index+1].url);
              if (index-1 >= 0) _initController(index-1, items[index-1].url);
            },
            itemBuilder: (context, index) {
              final item = items[index];
              _initController(index, item.url);
              final controller = _controllers[index];
              return Stack(
                fit: StackFit.expand,
                children: [
                  controller == null || !controller.value.isInitialized
                    ? Center(child: CircularProgressIndicator())
                    : FittedBox(
                        fit: BoxFit.cover,
                        child: SizedBox(
                          width: controller.value.size?.width ?? 0,
                          height: controller.value.size?.height ?? 0,
                          child: VideoPlayer(controller),
                        ),
                      ),
                  Positioned(right: 12, bottom: 24, child: Column(
                    children: [
                      IconButton(icon: Icon(Icons.favorite_border, size: 36, color: Colors.white), onPressed: () {
                        // TODO: implement like (update Firestore doc)
                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('أعجبك الفيديو')));
                      }),
                      IconButton(icon: Icon(Icons.comment, size: 36, color: Colors.white), onPressed: () {
                        Navigator.push(context, MaterialPageRoute(builder: (_) => CommentsScreen(videoId: item.id)));
                      }),
                      IconButton(icon: Icon(Icons.download, size: 36, color: Colors.white), onPressed: () async {
                        final path = await StorageService.downloadFile(item.url, '${item.id}.mp4');
                        if (path != null) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تم التحميل: $path')));
                        else ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('فشل التحميل')));
                      }),
                    ],
                  )),
                  Positioned(left: 12, bottom: 24, child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(item.title, style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
                      SizedBox(height: 6),
                      Text('بواسطة ${item.author}', style: TextStyle(color: Colors.white70)),
                    ],
                  )),
                ],
              );
            },
          );
        },
      ),
      drawer: Drawer(
        child: ListView(
          children: [
            UserAccountsDrawerHeader(accountName: Text(auth.user?.email ?? ''), accountEmail: Text('')),
            ListTile(title: Text('تسجيل الخروج'), onTap: () async { await auth.signOut(); }),
          ],
        ),
      ),
    );
  }
}
